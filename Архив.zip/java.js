const image1 = document.getElementById('image_1').src;
const image2 = document.getElementById('image_2').src;
const image3 = document.getElementById('image_3').src;

const slides = [
  {
    image: image1,
    menuId: 'data-slide1'
  },
  {
    image: image2,
    menuId: 'data-slide2'
  },
  {
    image: image3,
    menuId: 'data-slide3'
  }
];

let currentSlideIndex = 0;

// Функция для обновления отображения слайда и активного пункта меню
function updateSlideAndMenu() {
  slides.forEach(function(slide, index) {
    const slideElement = document.querySelector("#" + slide.menuId);
    
    //точки
    const dotElements = document.querySelectorAll('.dot');
    dotElements.forEach(function(dotElement, dotIndex,) {
      if (dotIndex === currentSlideIndex) {
        dotElement.classList.add('active');
      } else {
      dotElement.classList.remove('active');
      }
    });

    if (index === currentSlideIndex) {
      slideElement.classList.add('active');
      slideElement.firstChild.classList.add('active');
      document.querySelector("#image_" + (index + 1)).classList.add('active');
      dotElements[index].classList.add('active'); // Добавляем класс active для текущей точки

    } else {
      slideElement.classList.remove('active');
      slideElement.firstChild.classList.remove('active');
      document.querySelector("#image_" + (index + 1)).classList.remove('active');
    }
  });
}

// Обработчик события для кнопки "Prev"
document.getElementById('prevButton').addEventListener('click', function () {
  currentSlideIndex = (currentSlideIndex - 1 + slides.length) % slides.length;
  updateSlideAndMenu();
});

// Обработчик события для кнопки "Next"
document.getElementById('nextButton').addEventListener('click', function () {
  currentSlideIndex = (currentSlideIndex + 1) % slides.length;
  updateSlideAndMenu();
});

// Обработчики событий для пунктов меню
slides.forEach(function(slide) {
  document.getElementById(slide.menuId).addEventListener('click', function() {
    const clickedIndex = slides.findIndex(function(item) {
      return item.menuId === slide.menuId;
    });
    
    currentSlideIndex = clickedIndex;
    updateSlideAndMenu();
  });
});

// Инициализация слайдера
updateSlideAndMenu();
